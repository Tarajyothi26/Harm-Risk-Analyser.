import sqlite3

DB_NAME = "harm_data.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS flagged_content (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT,
            harm_index INTEGER,
            explanation TEXT
        )
    """)
    conn.commit()
    conn.close()

def save_flagged(content, harm_index, explanation):
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO flagged_content (content, harm_index, explanation) VALUES (?, ?, ?)",
        (content, harm_index, explanation)
    )
    conn.commit()
    conn.close()

def fetch_all():
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute("SELECT * FROM flagged_content")
    rows = cur.fetchall()
    conn.close()
    return rows
