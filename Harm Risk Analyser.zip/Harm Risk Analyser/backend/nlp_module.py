from textblob import TextBlob

HARMFUL_KEYWORDS = [
    "hack", "scam", "fraud", "steal",
    "password", "otp", "free money",
    "click this link", "bank details"
]

def analyze_text(text):
    blob = TextBlob(text)
    sentiment = blob.sentiment.polarity

    text_lower = text.lower()
    harmful_hits = [w for w in HARMFUL_KEYWORDS if w in text_lower]

    # Boost negativity if harmful intent exists
    if harmful_hits and sentiment >= 0:
        sentiment = -0.6

    return {
        "sentiment": sentiment,
        "harmful_keywords": harmful_hits
    }

