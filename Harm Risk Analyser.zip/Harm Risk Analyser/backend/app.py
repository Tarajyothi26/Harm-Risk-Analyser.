from flask import Flask, request, jsonify
from flask_cors import CORS

from nlp_module import analyze_text
from harm_index import calculate_harm_index
from database import init_db, save_flagged, fetch_all

app = Flask(__name__)
CORS(app)
init_db()

@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.json
    text = data.get("content", "")

    nlp_result = analyze_text(text)
    harm_index, explanation = calculate_harm_index(nlp_result)

    explanation_text = " ".join(explanation)

    if harm_index >= 5:
        save_flagged(text, harm_index, explanation_text)

    return jsonify({
        "harmIndex": harm_index,
        "explanation": explanation
    })

@app.route("/admin/flagged", methods=["GET"])
def admin():
    rows = fetch_all()
    return jsonify(rows)

if __name__ == "__main__":
    app.run(debug=True)
