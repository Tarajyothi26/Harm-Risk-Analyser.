def calculate_harm_index(nlp_result):
    score = 0
    explanation = []

    if nlp_result["sentiment"] < -0.3:
        score += 3
        explanation.append("Message has negative or fear-based emotion.")

    if nlp_result["harmful_keywords"]:
        score += 5
        explanation.append(
            f"Contains harmful actions: {', '.join(nlp_result['harmful_keywords'])}"
        )

    if score > 10:
        score = 10

    return score, explanation
