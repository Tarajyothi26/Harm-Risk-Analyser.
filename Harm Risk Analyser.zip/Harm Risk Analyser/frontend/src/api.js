const API_URL = "http://localhost:5000";

export async function analyzeContent(content) {
  const response = await fetch(`${API_URL}/analyze`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ content })
  });
  return response.json();
}

export async function fetchFlagged() {
  const response = await fetch(`${API_URL}/admin/flagged`);
  return response.json();
}
