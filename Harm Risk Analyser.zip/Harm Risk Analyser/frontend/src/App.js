import { useState } from "react";
import ContentInput from "./components/ContentInput";
import ResultView from "./components/ResultView";
import AdminDashboard from "./components/AdminDashboard";

function App() {
  const [result, setResult] = useState(null);

  return (
    <div style={{ padding: "20px" }}>
      <h1>Harm-Focused Misinformation Analyzer</h1>
      <ContentInput onResult={setResult} />
      <ResultView result={result} />
      <hr />
      <AdminDashboard />
    </div>
  );
}

export default App;
