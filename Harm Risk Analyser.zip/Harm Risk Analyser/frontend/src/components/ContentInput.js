import { useState } from "react";
import { analyzeContent } from "../api";

export default function ContentInput({ onResult }) {
  const [text, setText] = useState("");

  const submit = async () => {
    const result = await analyzeContent(text);
    onResult(result);
  };

  return (
    <div>
      <h3>Enter Viral Content</h3>
      <textarea
        rows="4"
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <br />
      <button onClick={submit}>Analyze</button>
    </div>
  );
}
