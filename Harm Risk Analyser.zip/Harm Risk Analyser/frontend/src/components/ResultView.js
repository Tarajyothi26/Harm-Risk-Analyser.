export default function ResultView({ result }) {
  if (!result) return null;

  return (
    <div>
      <h3>Harm Index: {result.harmIndex}</h3>
      <ul>
        {result.explanation.map((e, i) => (
          <li key={i}>{e}</li>
        ))}
      </ul>
    </div>
  );
}
