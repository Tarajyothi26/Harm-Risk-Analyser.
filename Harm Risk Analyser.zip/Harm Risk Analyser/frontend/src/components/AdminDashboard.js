import { useEffect, useState } from "react";
import { fetchFlagged } from "../api";

export default function AdminDashboard() {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetchFlagged().then(setData);
  }, []);

  return (
    <div>
      <h2>Admin Dashboard</h2>
      <table border="1">
        <thead>
          <tr>
            <th>ID</th>
            <th>Content</th>
            <th>Harm Index</th>
            <th>Explanation</th>
          </tr>
        </thead>
        <tbody>
          {data.map(row => (
            <tr key={row[0]}>
              <td>{row[0]}</td>
              <td>{row[1]}</td>
              <td>{row[2]}</td>
              <td>{row[3]}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
